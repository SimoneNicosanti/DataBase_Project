#include <stdbool.h>

const char *APP_TITLE = "English School Management System" ;

extern bool loadConfiguration() ;
