#pragma once

void exitWithError(char *errorMessage) ;

void *myMalloc(size_t allocSize) ;