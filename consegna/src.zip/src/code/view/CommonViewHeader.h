#pragma once

#include "TablePrinterHeader.h"
#include "../model/Class.h"

void printAllCourses(Class **classArray, int arrayLen) ;