#pragma once

#include <stdbool.h> 

bool loadConfiguration() ;