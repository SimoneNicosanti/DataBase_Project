#pragma once

#include "DatabaseUtilsHeader.h"
#include "../model/Class.h"
#include "Connector.h"
#include "../utils/SystemUtilsHeader.h"

DatabaseResult *selectAllCourses() ;